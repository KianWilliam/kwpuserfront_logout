<?php

/**
 * The public-facing functionality of the plugin.
 * @link       https://extensions.kwproductions121.com
 * @since      1.0.0
 *
 * @package    Kwpuflogout_for_wpuserfront
 * @subpackage Kwpuflogout_for_wpuserfront/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Kwpuflogout_for_wpuserfront
 * @subpackage Kwpuflogout_for_wpuserfront/public
 * @author     Kian William Nowrouzian<webarchitect@kwproductions121.ir>
 */
 
class Kwpuflogout_for_wpuserfront_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $kwpuflogout_userfront;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;
	
	protected $myscript;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $kwpuflogout_userfront, $version ) {

		$this->kwpuflogout_userfront = $kwpuflogout_userfront;
		$this->version = $version;
	
					add_action( 'wp_enqueue_scripts',array($this, 'kwpuflogout_enqueue'), 10, 1 );

		add_action( 'wp_ajax_kwpuflogout_my_action', array($this, 'kwpuflogout_ajax_handler'), 0 );
				add_action( 'wp_ajax_nopriv_kwpuflogout_my_action', array($this, 'kwpuflogout_ajax_handler'), 0 );

									


	}
/**
 * Handles my AJAX request.
 */
 

public function kwpuflogout_enqueue($hook) {
 /*  if ( 'myplugin_settings.php' !== $hook ) {
      return;
   }*/
	
	
	
		            $kwpuflogout = get_option('kwpuflogout_option');
     $user = wp_get_current_user();
	 $roles = $user->roles;
	 
	  if($roles[0]=='administrator'){
	            $url = $kwpuflogout['kwpuflogout_url'];
      
	}	
    else
			 if($roles[0]=='editor'){

		
				$url = $kwpuflogout['kwpuflogout_urlb'];
			 	 

			 }
			 else
				 if($roles[0]=='author'){
				  $url = $kwpuflogout['kwpuflogout_urlc'];
				 
				 }
				 else
					 if($roles[0]=='contributor'){
						 
				 $url= $kwpuflogout['kwpuflogout_urld'];
				 
					 }
					 else
					 {
						 $url = $kwpuflogout['kwpuflogout_urle'];
						 
					 }
	
	
	
   wp_enqueue_script(
      'ajax-script',
      plugins_url( '/js/kwpuflogout-for-wpuserfront-public.js', __FILE__ ),
      array( 'jquery' ),
      true
   );
   
      $title_nonce = wp_create_nonce( 'kwpuflogout_haha' );
  wp_localize_script(
      'ajax-script',
      'ajax_obj', 
      array(
         'ajax_url' => admin_url( 'admin-ajax.php' ),
         'nonce'    => $title_nonce,
		 'url'=>$url,
		 
      )
   );
   


}
//_ajax_handler
 
public function kwpuflogout_ajax_handler() {

	check_ajax_referer('kwpuflogout_haha');
wp_logout();


	wp_die(); 
}
	
	

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->kwpuflogout_userfront, plugin_dir_url( __FILE__ ) . 'css/kwpuflogout-for-wpuserfront-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->kwpuflogout_userfront, plugin_dir_url( __FILE__ ) . 'js/kwpuflogout-for-wpuserfront-public.js', array( 'jquery' ), $this->version, false );
		//wp_enqueue_script( $this->kwpsbb_for_woocommerce, 'https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js', array('jquery') );

	}

}

<?php 

add_action( 'wp_ajax_my_action', 'my_action' );

function my_action() {
	global $wpdb; // this is how you get access to the database

	$whatever =  $_POST['name'] ;

	wp_redirect('http://localhost/wp23a');
	exit();

//        echo $whatever;
		

	wp_die(); // this is required to terminate immediately and return a proper response
}
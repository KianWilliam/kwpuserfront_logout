<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://extensions.kwproductions121.ir
 * @since      1.0.0
 *
 * @package    Kwpuflogout_for_wpuserfront
 * @subpackage Kwpuflogout_for_wpuserfront/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Kwpuflogout_for_wpuserfront
 * @subpackage Kwpuflogout_for_wpuserfront/includes
 * @author     Kian William Nowrouzian<webarchitect@kwproductions121.ir>
 */
class Kwpuflogout_for_wpuserfront_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}

<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://extensions.kwproductions121.ir
 * @since      1.0.0
 *
 * @package    Kwpuflogout_for_wpuserfront
 * @subpackage Kwpuflogout_for_wpuserfront/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Kwpuflogout_for_wpuserfront
 * @subpackage Kwpuflogout_for_wpuserfront/admin
 * @author     Kian William Nowrouzian<webarchitect@kwproductions121.ir>
 */
 

	
class Kwpuflogout_for_wpuserfront_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $kwpuflogout_userfront;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;
	protected $kwpuflogout_defaults;
	protected $fsflag;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->kwpuflogout_userfront = 'kwpuflogout-for-userfront';
		$this->version = $version;
		//get home page, wp function. or use db
			$this->kwpuflogout_defaults = array(
			'kwpuflogout_url' => get_home_url().'/wp-admin','kwpuflogout_urlb' => get_home_url(),
			'kwpuflogout_urlc' => get_home_url(),'kwpuflogout_urld' => get_home_url(),
			'kwpuflogout_urle' => get_home_url(),			 
			);
			
	            add_action('admin_menu', array($this, 'kwpuflogout_page_menu'), 13);
		        add_filter('admin_menu', array($this, 'kwpuflogout_tab_menu'), 20);
				add_action('admin_init', array( $this, 'kwpuflogout_settings_init' ));
			

	}
	
	public function kwpuflogout_page_menu()
	{
		     add_menu_page('KWPuflogout', 'KWPuflogout', 'manage_options', 'kwpuflogout', array($this, 'kwpuflogout_page_html'), plugins_url('logout.gif', __FILE__) );
  
	}

    public function kwpuflogout_tab_menu($tabs) {
        $tabs = esc_html__('General', 'kwpuflogout-for-userfront');
        return $tabs;
    }
	
public function kwpuflogout_settings_init() {

  
      $settings_args = array(
            'type' => 'array', 
            'sanitize_callback' => array( $this, 'kwpuflogout_sanitize_options' ),
            'show_in_rest' => false,
            'default' => $this->kwpuflogout_defaults,
            ); 
			
				
		
      add_settings_section(
      // ID used to identify this section and with which to register options
      'kwpuflogout_settings_section', 
      // Title to be displayed on the administration page
      'KWPUFLOGOUT for Userfront',  
      // Callback used to render the description of the section
       array( $this, 'kwpuflogout_settings_section' ),    
      // Page on which to add this section of options
      'kwpuflogout'                   
    );
	
	
		  
		  $data_r = array('kwpuflogout_url' => get_home_url().'/wp-admin', 
		  'kwpuflogout_urlb' => get_home_url(), 
		  'kwpuflogout_urlc' => get_home_url(), 
		  'kwpuflogout_urld' => get_home_url(), 
		  'kwpuflogout_urle' => get_home_url(), 
		  );
// add a new option
add_option('kwpuflogout_option', $data_r);	
		  
		   register_setting(
            'kwpuflogout',
            'kwpuflogout_option',
			$settings_args
            );
			
		  
  


    
  
		  
    add_settings_field(
      'kwpuflogout_url',
        __( 'Url for Administrator', 'kwpuflogout' ),
      array( $this, 'kwpuflogout_url' ),
      'kwpuflogout',
      'kwpuflogout_settings_section',
	    array(
            'label_for'         => 'kwpuflogout_url',
            'class'             => 'kwpuflogout_row',
            'kwpuflogout_custom_data' => 'custom',
        )
    );
		
		
    
  
		  
    add_settings_field(
      'kwpuflogout_urlb',
        __( 'Url for Editors', 'kwpuflogout' ),
      array( $this, 'kwpuflogout_urlb' ),
      'kwpuflogout',
      'kwpuflogout_settings_section',
	    array(
            'label_for'         => 'kwpuflogout_urlb',
            'class'             => 'kwpuflogout_row',
            'kwpuflogout_custom_data' => 'custom',
        )
    );
	
    add_settings_field(
      'kwpuflogout_urlc',
        __( 'Url for Authors', 'kwpuflogout' ),
      array( $this, 'kwpuflogout_urlc' ),
      'kwpuflogout',
      'kwpuflogout_settings_section',
	    array(
            'label_for'         => 'kwpuflogout_urlc',
            'class'             => 'kwpuflogout_row',
            'kwpuflogout_custom_data' => 'custom',
        )
    );
		
	  
  
		  
    add_settings_field(
      'kwpuflogout_urld',
        __( 'Url for Contributors', 'kwpuflogout' ),
      array( $this, 'kwpuflogout_urld' ),
      'kwpuflogout',
      'kwpuflogout_settings_section',
	    array(
            'label_for'         => 'kwpuflogout_urld',
            'class'             => 'kwpuflogout_row',
            'kwpuflogout_custom_data' => 'custom',
        )
    );
	
	 
    
  
		  
    add_settings_field(
      'kwpuflogout_urle',
        __( 'Url for Subscribers', 'kwpuflogout' ),
      array( $this, 'kwpuflogout_urle' ),
      'kwpuflogout',
      'kwpuflogout_settings_section',
	    array(
            'label_for'         => 'kwpuflogout_urle',
            'class'             => 'kwpuflogout_row',
            'kwpuflogout_custom_data' => 'custom',
        )
    );
		
		


    
  	
		
		//$setting = get_option('kwpuflogout_option');
	//	var_dump($setting);
		//exit();


}
	
	public function kwpuflogout_settings_section($args)
	{
	   echo '<p id="'.esc_html($args['id']).'">The setting below apply to  KWP-UFLogout for wpuserfront functionality.</p>';

	}
	public function kwpuflogout_sanitize_options($input)
	{

				$valid = array();
				$valid = $input;
				$error = "";
				//var_dump($valid['kwpuflogout_groupa']);
				//exit();
				$valid['kwpuflogout_url']=wp_kses_post($input['kwpuflogout_url']);
								//var_dump($valid['kwpuflogout_url']);
                 //exit();
				if(empty($valid['kwpuflogout_url']) || !preg_match('/^http[s]{0,1}:([a-zA-Z0-9\?\/\.\-\=&_:\s])+$/' , $valid['kwpuflogout_url']))
				{
					add_settings_error('kwpuflogout', esc_attr('mycode121'), __("url can not be empty , or the input syntax is wrong,  we return its value to default!", "wpse"), 'error' );
					//$error = "font-size can not be empty , add no px and only input numbers, we return its value to default!";
					$valid['kwpuflogout_url'] = wp_kses_post($this->kwpuflogout_defaults['kwpuflogout_url']);
				}
					$valid['kwpuflogout_urlb']=wp_kses_post($input['kwpuflogout_urlb']);
					if(empty($valid['kwpuflogout_urlb']) || !preg_match('/^http[s]{0,1}:([a-zA-Z0-9\?\/\.\-\=&_:\s])+$/' , $valid['kwpuflogout_urlb']) )
				{
					add_settings_error('kwpuflogout', esc_attr('mycode121'), __("url can not be empty , or the input syntax is wrong,  we return its value to default!", "wpse"), 'error' );
					//$error = "font-size can not be empty , add no px and only input numbers, we return its value to default!";
					$valid['kwpuflogout_urlb'] = wp_kses_post($this->kwpuflogout_defaults['kwpuflogout_urlb']);
				}
					$valid['kwpuflogout_urlc']=wp_kses_post($input['kwpuflogout_urlc']);
					if(empty($valid['kwpuflogout_urlc']) || !preg_match('/^http[s]{0,1}:([a-zA-Z0-9\?\/\.\-\=&_:\s])+$/' , $valid['kwpuflogout_urlc']))
				{
					add_settings_error('kwpuflogout', esc_attr('mycode121'), __("url can not be empty , or the input syntax is wrong,  we return its value to default!", "wpse"), 'error' );
					//$error = "font-size can not be empty , add no px and only input numbers, we return its value to default!";
					$valid['kwpuflogout_urlc'] = wp_kses_post($this->kwpuflogout_defaults['kwpuflogout_urlc']);
				}
					$valid['kwpuflogout_urld']=wp_kses_post($input['kwpuflogout_urld']);
					if(empty($valid['kwpuflogout_urld']) || !preg_match('/^http[s]{0,1}:([a-zA-Z0-9\?\/\.\-\=&_:\s])+$/' , $valid['kwpuflogout_urld']) )
				{
					add_settings_error('kwpuflogout', esc_attr('mycode121'), __("url can not be empty , or the input syntax is wrong,  we return its value to default!", "wpse"), 'error' );
					//$error = "font-size can not be empty , add no px and only input numbers, we return its value to default!";
					$valid['kwpuflogout_urld'] = wp_kses_post($this->kwpuflogout_defaults['kwpuflogout_urld']);
				}
					$valid['kwpuflogout_urle']=wp_kses_post($input['kwpuflogout_urle']);
					if(empty($valid['kwpuflogout_urle']) || !preg_match('/^http[s]{0,1}:([a-zA-Z0-9\?\/\.\-\=&_:\s])+$/' , $valid['kwpuflogout_urle']))
				{
					add_settings_error('kwpuflogout', esc_attr('mycode121'), __("url can not be empty , or the input syntax is wrong,  we return its value to default!", "wpse"), 'error' );
					//$error = "font-size can not be empty , add no px and only input numbers, we return its value to default!";
					$valid['kwpuflogout_urle'] = wp_kses_post($this->kwpuflogout_defaults['kwpuflogout_urle']);
				}
			/*	if(empty($valid['kwpuflogout_groupa']))
				{
					add_settings_error('kwpuflogout', esc_attr('mycode121'), __("The field could not be empty!", "wpse"), 'error' );
					//$error = "font-size can not be empty , add no px and only input numbers, we return its value to default!";
					$valid['kwpuflogout_groupa'] = wp_kses_post($this->kwpuflogout_defaults['kwpuflogout_groupa']);
				}*/

				return $valid;

	}
	
	public function kwpuflogout_url($args)
	{
		
		$setting = get_option('kwpuflogout_option');
		
		?>
		<input type="text" id="kwpuflogout_option[kwpuflogout_url]" data-custom="<?php echo esc_attr($args['kwpuflogout_custom_data']) ?>" name="kwpuflogout_option[kwpuflogout_url]" value="<?php echo isset($setting) ? esc_attr($setting['kwpuflogout_url']) : ''; ?>" />
		<?php
		
	}
	
	
	
	public function kwpuflogout_urlb($args)
	{
		
		$setting = get_option('kwpuflogout_option');
		
		?>
		<input type="text" id="kwpuflogout_option[kwpuflogout_urlb]" data-custom="<?php echo esc_attr($args['kwpuflogout_custom_data']) ?>" name="kwpuflogout_option[kwpuflogout_urlb]" value="<?php echo isset($setting) ? esc_attr($setting['kwpuflogout_urlb']) : ''; ?>" />
		<?php
		
	}
	
	
	public function kwpuflogout_urlc($args)
	{
		
		$setting = get_option('kwpuflogout_option');
		
		?>
		<input type="text" id="kwpuflogout_option[kwpuflogout_urlc]" data-custom="<?php echo esc_attr($args['kwpuflogout_custom_data']) ?>" name="kwpuflogout_option[kwpuflogout_urlc]" value="<?php echo isset($setting) ? esc_attr($setting['kwpuflogout_urlc']) : ''; ?>" />
		<?php
		
	}
	
	public function kwpuflogout_urld($args)
	{
		
		$setting = get_option('kwpuflogout_option');
		
		?>
		<input type="text" id="kwpuflogout_option[kwpuflogout_urld]" data-custom="<?php echo esc_attr($args['kwpuflogout_custom_data']) ?>" name="kwpuflogout_option[kwpuflogout_urld]" value="<?php echo isset($setting) ? esc_attr($setting['kwpuflogout_urld']) : ''; ?>" />
		<?php
		
	}
	public function kwpuflogout_urle($args)
	{
		
		$setting = get_option('kwpuflogout_option');
		
		?>
		<input type="text" id="kwpuflogout_option[kwpuflogout_urle]" data-custom="<?php echo esc_attr($args['kwpuflogout_custom_data']) ?>" name="kwpuflogout_option[kwpuflogout_urle]" value="<?php echo isset($setting) ? esc_attr($setting['kwpuflogout_urle']) : ''; ?>" />
		<?php
		
	}
	public function kwpuflogout_page_html()
	{
		
			if( !is_plugin_active( 'wp-user-frontend/wpuf.php' ) ) {
			$message = __('Your wp user frontend plugin should be activated first to be able to use this plugin!', 'kwpuflogout_for_userfront' );
			add_settings_error( 'kwpuflogout', esc_attr( 'kwpuflogout_userfront_disabled' ), $message, 'error' );
		}
	//	settings_errors('kwpuflogout');
			


		if(!current_user_can('manage_options'))
		{
			return;
		}
		if(isset($_GET['settings-updated']))
		{
			add_settings_error('kwpuflogout', 'kwpuflogout_message', __('Settings Saved', 'kwpuflogout'), 'update');
		}
			
			//var_dump($_GET);
			//var_dump($_POST);
	
			settings_errors('kwpuflogout');
			?>
			<div class="wrap">
			<h1><?php echo esc_html(get_admin_page_title()); ?></h1>
			<form method="post" action="options.php">
			 <?php 

			 settings_fields('kwpuflogout');
			  do_settings_sections('kwpuflogout');

			 submit_button('Save Settings');
			 ?>
			</form>
			<?php
		
	}
	

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->kwpuflogout_userfront, plugin_dir_url( __FILE__ ) . 'css/kwpuflogout-for-userfront-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		         global $wp_version;

        if (is_admin()) {

		wp_enqueue_script( $this->kwpuflogout_userfront, plugin_dir_url( __FILE__ ) . 'js/kwpuflogout-for-userfront-admin.js', array( 'jquery' ), $this->version, false );
		
          

		}
	}

}
